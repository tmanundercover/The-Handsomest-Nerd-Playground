// Define some parameters
import {defineString} from "firebase-functions/params";

export const exampleEnvVar = defineString('EXAMPLE_ENV_VAR');
export const exampleEnvVar2 = defineString('EXAMPLE_ENV_VAR_2');
export const exampleEnvVar3 = defineString('EXAMPLE_ENV_VAR_3');