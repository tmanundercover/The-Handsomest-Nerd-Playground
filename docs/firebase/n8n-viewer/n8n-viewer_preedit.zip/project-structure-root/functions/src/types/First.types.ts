export interface FirstType {
    id: string;
    name: string;
    age: number;
    description: string;
    image: string;
}